import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashbourdPage } from './page/dashbourd-page/dashbourd-page';

const routes: Routes = [
  {
    path: '',
    component: DashbourdPage ,
    pathMatch: 'full'
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DashboardRoutingModule {}
